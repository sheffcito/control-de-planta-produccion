import os
import sqlite3
import flet as ft

def obtener_ruta_db():
    """Determina la ruta correcta de la DB tanto en PC como en el APK del celular."""
    # En Android, esta variable apunta al almacenamiento seguro y privado de la app
    directorio = os.environ.get("FLET_APP_DATA_DIR", "")
    if not directorio:
        # Si estás probando o desarrollando en la PC, usa la carpeta actual
        directorio = os.getcwd()
    return os.path.join(directorio, "produccion_planta.db")

def inicializar_base_datos():
    ruta = obtener_ruta_db()
    conexion = sqlite3.connect(ruta)
    cursor = conexion.cursor()
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS turnos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sap TEXT,
            maquina TEXT,
            producto TEXT,
            unidades INTEGER
        )
    """)
    conexion.commit()
    conexion.close()

def guardar_en_db(sap, maquina, producto, unidades):
    ruta = obtener_ruta_db()
    conexion = sqlite3.connect(ruta)
    cursor = conexion.cursor()
    cursor.execute("""
        INSERT INTO turnos (sap, maquina, producto, unidades)
        VALUES (?, ?, ?, ?)
    """, (sap, maquina, producto, unidades))
    conexion.commit()
    conexion.close()
    
def guardar_en_db(sap, maquina, producto, unidades):
    """Inserta un nuevo registro de producción en la base de datos."""
    conexion = sqlite3.connect("produccion_planta.db")
    cursor = conexion.cursor()
    cursor.execute("""
        INSERT INTO turnos (sap, maquina, producto, unidades)
        VALUES (?, ?, ?, ?)
    """, (sap, maquina, producto, unidades))
    conexion.commit()
    conexion.close()

# ==========================================
# 2. INTERFAZ GRÁFICA (Flet App móvil)
# ==========================================
def main(page: ft.Page):
    # Configuración de la ventana simulando la pantalla de un celular
    page.title = "Control de Producción"
    page.window_width = 380
    page.window_height = 700
    page.horizontal_alignment = ft.CrossAxisAlignment.CENTER
    page.scroll = ft.ScrollMode.AUTO

    # Inicializamos la DB al arrancar la app
    inicializar_base_datos()

    # Componentes Visuales (Widgets)
    titulo = ft.Text("REGISTRO DE TURNO", size=24, weight=ft.FontWeight.BOLD, color=ft.Colors.BLUE)
    
    input_sap = ft.TextField(label="Número de SAP / Orden", icon=ft.Icons.RECEIPT)
    input_maquina = ft.TextField(label="Tipo de Máquina / Línea", icon=ft.Icons.PRECISION_MANUFACTURING)
    input_producto = ft.TextField(label="Nombre del Producto", icon=ft.Icons.INVENTORY_2)
    input_unidades = ft.TextField(label="Unidades Producidas", icon=ft.Icons.NUMBERS, keyboard_type=ft.KeyboardType.NUMBER)
    
    texto_estado = ft.Text("", color=ft.Colors.GREEN_700, weight=ft.FontWeight.BOLD)

    # Función que se ejecuta al presionar el botón
    def boton_guardar_click(e):
        # Validación rápida de números
        try:
            unidades = int(input_unidades.value)
        except ValueError:
            texto_estado.value = "⚠️ Error: Las unidades deben ser un número."
            texto_estado.color = ft.Colors.RED_700
            page.update()
            return

        # Guardar en SQLite
        guardar_en_db(
            input_sap.value,
            input_maquina.value,
            input_producto.value,
            unidades
        )

        # Limpiar campos y avisar al supervisor
        input_sap.value = ""
        input_maquina.value = ""
        input_producto.value = ""
        input_unidades.value = ""
        texto_estado.value = "✅ ¡Datos guardados en SQLite con éxito!"
        texto_estado.color = ft.Colors.GREEN_700
        page.update()

    btn_guardar = ft.ElevatedButton(
        content=ft.Text("Guardar en Planta", weight=ft.FontWeight.BOLD),
        icon=ft.Icons.SAVE,
        on_click=boton_guardar_click,
        style=ft.ButtonStyle(shape=ft.RoundedRectangleBorder(radius=8)),
        width=250
    )
    # Agregar los elementos a la vista del celular
    page.add(
        ft.Column(
            controls=[
                titulo,
                ft.Divider(height=20, color=ft.Colors.TRANSPARENT),
                input_sap,
                input_maquina,
                input_producto,
                input_unidades,
                ft.Divider(height=10, color=ft.Colors.TRANSPARENT),
                btn_guardar,
                ft.Divider(height=10, color=ft.Colors.TRANSPARENT),
                texto_estado
            ],
            horizontal_alignment=ft.CrossAxisAlignment.CENTER,
            spacing=15
        )
    )

# Ejecutar la aplicación
if __name__ == "__main__":
    ft.app(target=main)